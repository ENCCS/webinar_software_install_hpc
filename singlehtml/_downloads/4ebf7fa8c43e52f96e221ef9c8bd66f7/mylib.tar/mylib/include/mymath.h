void manual_gemm(int n, const double *restrict A, const double *restrict B, double *restrict C);
