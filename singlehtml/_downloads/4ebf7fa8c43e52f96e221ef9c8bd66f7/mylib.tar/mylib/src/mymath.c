void manual_gemm(int n, const double *restrict A, const double *restrict B, double *restrict C){
  for (int i = 0; i < n; i++) {
    for (int k = 0; k < n; k++) {
      double aik = A[i*n + k];
      for (int j = 0; j < n; j++) {
        C[i*n + j] += aik * B[k*n + j];
      }
    }
  }
}
